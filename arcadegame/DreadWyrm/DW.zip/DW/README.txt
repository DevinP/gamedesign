DREAD WYRM
Team TeamTeam
Patrick Bloem
Jess Tate
Caleb Pentecost
Devin Pentecost

/////////////////////////////
INSTALLATION:
/////////////////////////////
To install run setup.exe. Follow the instructions and install the application. You should be good to go.

/////////////////////////////
TO PLAY:
/////////////////////////////
Upon running the game, you will be presented with the intro screen. As listed on the intro screen, you begin the game by pressing either 
Spacebar (Regular game) or N (Nux-Mode game). You will then be presented with the instructions screen. It will describe the controls, such 
as arrow-key movement, as well as the prey that is found in the game.

As a bonus, you may press Left Control (To roar!) or Right Shift (To change songs), these controls are not listed in the instructions 
screen and are classified as Easter Eggs!

To quit the game, click on the X in the corner of the window.